# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


class Hyperparams(object):
    '\n    A basic ``Hyperparams`` class to be used as a type for ``Hyperparams``\n    type argument in primitive interfaces.\n    '
