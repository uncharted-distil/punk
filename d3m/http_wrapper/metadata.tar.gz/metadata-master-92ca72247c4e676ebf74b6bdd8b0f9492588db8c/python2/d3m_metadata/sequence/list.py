# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import typing
from ..metadata import Metadata
__all__ = ('List',)
T = typing.TypeVar('T')


class List(typing.List[T]):
    '\n    Extended Python standard `typing.List` with the `__metadata__` attribute.\n\n    You have to create a subclass of this generic type with specified element type before\n    you can instantiate lists.\n\n    One can use various base and sequence types as its elements:\n\n    * `numpy.ndarray`\n    * `numpy.matrix`\n    * `pandas.DataFrame`\n    * `pandas.SparseDataFrame`\n    * `d3m_metadata.base.Graph`\n    * ``str``\n    * ``bytes``\n    * ``bool``\n    * ``float``\n    * ``int``\n    * ``dict`` (consider using `typing.Dict`, `typing.NamedTuple`, or `TypedDict`)\n    '
    __metadata__ = None  # type: Metadata
