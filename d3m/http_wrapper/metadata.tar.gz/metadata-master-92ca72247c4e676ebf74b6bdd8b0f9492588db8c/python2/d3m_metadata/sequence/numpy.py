# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import typing
from ..metadata import Metadata
__all__ = ()  # type: typing.Any
try:
    import numpy
    __all__ = ('ndarray', 'matrix')

    class ndarray(numpy.ndarray):
        '\n        Extended `numpy.ndarray` with the `__metadata__` attribute.\n\n        `numpy.ndarray` **does not** allow directly attaching `__metadata__` attribute to an instance.\n        '
        __metadata__ = None  # type: Metadata

    class matrix(numpy.matrix):
        '\n        Extended `numpy.matrix` with the `__metadata__` attribute.\n\n        `numpy.matrix` **does** allow directly attaching `__metadata__` attribute to an instance.\n        '
        __metadata__ = None  # type: Metadata
    typing.Sequence.register(numpy.ndarray)
    typing.Sequence.register(numpy.matrix)
except ImportError:
    pass
