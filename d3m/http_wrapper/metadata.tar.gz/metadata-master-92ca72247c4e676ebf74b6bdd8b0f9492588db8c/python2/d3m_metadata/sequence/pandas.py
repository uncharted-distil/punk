# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import typing
from ..metadata import Metadata
__all__ = ()  # type: typing.Any
try:
    import pandas
    __all__ = ('DataFrame', 'SparseDataFrame')

    class DataFrame(pandas.DataFrame):
        '\n        Extended `pandas.DataFrame` with the `__metadata__` attribute.\n\n        `pandas.DataFrame` **does** allow directly attaching `__metadata__` attribute to an instance.\n        '
        __metadata__ = None  # type: Metadata

    class SparseDataFrame(pandas.SparseDataFrame):
        '\n        Extended `pandas.SparseDataFrame` with the `__metadata__` attribute.\n\n        `pandas.SparseDataFrame` **does** allow directly attaching `__metadata__` attribute to an instance.\n        '
        __metadata__ = None  # type: Metadata
    typing.Sequence.register(pandas.DataFrame)
    typing.Sequence.register(pandas.SparseDataFrame)
except ImportError:
    pass
