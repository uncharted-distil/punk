# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


class Metadata(object):
    '\n    A basic ``Metadata`` class to be used as a value for `__metadata__` attribute\n    on values passed between primitives.\n    '
