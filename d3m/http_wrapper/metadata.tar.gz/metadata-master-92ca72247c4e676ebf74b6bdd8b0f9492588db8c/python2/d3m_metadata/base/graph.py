# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from six import with_metaclass as _py_backwards_six_withmetaclass
import abc
__all__ = ('Graph',)


class Graph(
        _py_backwards_six_withmetaclass(abc.ABCMeta, *[object])):
    '\n    This class provides an interface of methods that operate on the graph.\n\n    Attributes\n    ----------\n    adjacency_matrix : scipy csr matrix\n\n    _num_vertices : int\n        Number of vertices\n\n    _num_edges : int\n        Number of edges\n\n    _directed : boolean\n        Declares if it is a directed graph or not\n\n    _weighted : boolean\n        Declares if it is a weighted graph or not\n\n    _dangling_nodes : int numpy array\n        Nodes with zero edges\n\n    d : float64 numpy vector\n        Degrees vector\n\n    dn : float64 numpy vector\n        Component-wise reciprocal of degrees vector\n\n    d_sqrt : float64 numpy vector\n        Component-wise square root of degrees vector\n\n    dn_sqrt : float64 numpy vector\n        Component-wise reciprocal of sqaure root degrees vector\n\n    vol_G : float64 numpy vector\n        Volume of graph\n\n    components : list of sets\n        Each set contains the indices of a connected component of the graph\n\n    number_of_components : int\n        Number of connected components of the graph\n\n    bicomponents : list of sets\n        Each set contains the indices of a biconnected component of the graph\n\n    number_of_bicomponents : int\n        Number of connected components of the graph\n\n    core_numbers : dictionary\n        Core number for each vertex\n    '

    def __init__(self, filename, file_type='gml', separator='\t'):
        "\n        Initializes the graph from a gml or a edgelist file and initializes the attributes of the class.\n\n        Parameters\n        ----------\n        filename : string\n            Name of the file, for example 'JohnsHopkins.edgelist' or 'JohnsHopkins.gml'.\n\n        dtype : string\n            Type of file. Currently only 'edgelist' and 'gml' are supported.\n            Default = 'gml'\n\n        separator : string\n            used if file_type = 'edgelist'\n            Default = '\t'\n        "
        self.adjacency_matrix = None
        self._num_vertices = None
        self._num_edges = None
        self._directed = None
        self._weighted = None
        self._dangling_nodes = None
        self.d = None
        self.dn = None
        self.d_sqrt = None
        self.dn_sqrt = None
        self.vol_G = None
        self.components = None
        self.number_of_components = None
        self.number_of_bicomponents = None
        self.bicomponents = None
        self.core_numbers = None

    @abc.abstractmethod
    def import_text(self, filename, separator):
        '\n        Reads text from filename.\n        '

    @abc.abstractmethod
    def read_graph(self, filename, file_type='gml', separator='\t'):
        "\n        Reads the graph from a gml or a edgelist file and initializes the class attribute adjacency_matrix.\n\n        Parameters\n        ----------\n        filename : string\n            Name of the file, for example 'JohnsHopkins.edgelist' or 'JohnsHopkins.gml'.\n\n        dtype : string\n            Type of file. Currently only 'edgelist' and 'gml' are supported.\n            Default = 'gml'\n\n        separator : string\n            used if file_type = 'edgelist'\n            Default = '\t'\n        "

    @abc.abstractmethod
    def compute_statistics(self):
        '\n        Computes statistics for the graph. It updates the class attributes. The user needs to\n        read the graph first before calling this method by calling the read_graph method from this class.\n        '

    @abc.abstractmethod
    def connected_components(self):
        '\n        Computes the connected components of the graph. It stores the results in class attributes\n        components and number_of_components. The user needs to call read the graph first before\n        calling this function by calling the read_graph function from this class.\n        This function calls Networkx.\n        '

    @abc.abstractmethod
    def is_disconnected(self):
        '\n        The output can be accessed from the graph object that calls this function.\n\n        Checks if the graph is a disconnected graph. It prints the result as a comment and\n        returns True if the graph is disconnected, or false otherwise. The user needs to\n        call read the graph first before calling this function by calling the read_graph\n        function from this class. This function calls Networkx.\n\n        Returns\n        -------\n        True\n             If connected\n\n        False\n             If disconnected\n        '

    @abc.abstractmethod
    def biconnected_components(self):
        '\n        Computes the biconnected components of the graph. It stores the results in class attributes bicomponents\n        and number_of_bicomponents. The user needs to call read the graph first before calling this\n        function by calling the read_graph function from this class. This function calls Networkx.\n        '

    @abc.abstractmethod
    def core_number(self):
        '\n        Returns the core number for each vertex. A k-core is a maximal\n        subgraph that contains nodes of degree k or more. The core number of a node\n        is the largest value k of a k-core containing that node. The user needs to\n        call read the graph first before calling this function by calling the read_graph\n        function from this class. The output can be accessed from the graph object that\n        calls this function. It stores the results in class attribute core_numbers.\n        '
