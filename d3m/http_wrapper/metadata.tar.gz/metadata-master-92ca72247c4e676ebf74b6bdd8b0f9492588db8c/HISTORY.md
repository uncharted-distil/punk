## vNEXT

* A problem schema parsing and Python enumerations added in
  `d3m_metadata.schema.problem` module.
* Package renamed from `d3m_types` to `d3m_metadata`.
* Repository migrated to gitlab.com and made public.
* A standard set of sequence and base types have been defined.
