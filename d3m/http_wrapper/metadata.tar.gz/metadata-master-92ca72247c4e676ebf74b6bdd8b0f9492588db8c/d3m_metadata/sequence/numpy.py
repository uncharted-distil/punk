import typing

from ..metadata import Metadata

__all__ = ()  # type: typing.Any

try:
    import numpy

    __all__ = ('ndarray', 'matrix')

    class ndarray(numpy.ndarray):
        """
        Extended `numpy.ndarray` with the `__metadata__` attribute.

        `numpy.ndarray` **does not** allow directly attaching `__metadata__` attribute to an instance.
        """

        __metadata__ = None  # type: Metadata

    class matrix(numpy.matrix):
        """
        Extended `numpy.matrix` with the `__metadata__` attribute.

        `numpy.matrix` **does** allow directly attaching `__metadata__` attribute to an instance.
        """

        __metadata__ = None  # type: Metadata

    typing.Sequence.register(numpy.ndarray)
    typing.Sequence.register(numpy.matrix)

except ImportError:
    pass
