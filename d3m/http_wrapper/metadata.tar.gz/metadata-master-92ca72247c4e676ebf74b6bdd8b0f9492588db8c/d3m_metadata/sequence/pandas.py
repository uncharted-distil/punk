import typing

from ..metadata import Metadata

__all__ = ()  # type: typing.Any

try:
    import pandas

    __all__ = ('DataFrame', 'SparseDataFrame')

    class DataFrame(pandas.DataFrame):
        """
        Extended `pandas.DataFrame` with the `__metadata__` attribute.

        `pandas.DataFrame` **does** allow directly attaching `__metadata__` attribute to an instance.
        """

        __metadata__ = None  # type: Metadata

    class SparseDataFrame(pandas.SparseDataFrame):
        """
        Extended `pandas.SparseDataFrame` with the `__metadata__` attribute.

        `pandas.SparseDataFrame` **does** allow directly attaching `__metadata__` attribute to an instance.
        """

        __metadata__ = None  # type: Metadata

    typing.Sequence.register(pandas.DataFrame)
    typing.Sequence.register(pandas.SparseDataFrame)

except ImportError:
    pass
