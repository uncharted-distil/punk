

class Hyperparams:
    """
    A basic ``Hyperparams`` class to be used as a type for ``Hyperparams``
    type argument in primitive interfaces.
    """
