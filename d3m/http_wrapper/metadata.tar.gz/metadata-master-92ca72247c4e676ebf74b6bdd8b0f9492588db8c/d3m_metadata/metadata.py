

class Metadata:
    """
    A basic ``Metadata`` class to be used as a value for `__metadata__` attribute
    on values passed between primitives.
    """
