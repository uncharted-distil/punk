# D3M types and metadata

This repository aim is to standardize types of values being passed between
primitives and metadata associated with them. Because those values can also be
primitives themselves (or better, their instances), and datasets, this
repository also standardizes metadata for primitives.

While theoretically any value could be passed between primitives, limiting
them to a known set of values can make primitives more compatible and values
easier to introspect by TA3 systems.

## Installation

This package works on both Python 2.7 and Python 3.5+.

You can run
```
pip install -r requirements.txt
pip install .
```
in the root directory of this repository to install the `d3m_metadata` package.

## Changelog

See [HISTORY.md](./HISTORY.md) for summary of changes to this package.

## Sequence types

All values passed between primitives should implement a `Sequence`
and provide `__metadata__` attribute with metadata.

`d3m_metadata.sequence` module exposes such standard types:

* `ndarray` – [`numpy.ndarray`](https://docs.scipy.org/doc/numpy/reference/generated/numpy.ndarray.html) with support for `__metadata__` attribute
* `matrix` – [`numpy.matrix`](https://docs.scipy.org/doc/numpy/reference/generated/numpy.matrix.html) with support for `__metadata__` attribute
* `DataFrame` – [`pandas.DataFrame`](https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.html) with support for `__metadata__` attribute
* `SparseDataFrame` – [`pandas.SparseDataFrame`](https://pandas.pydata.org/pandas-docs/stable/sparse.html#sparsedataframe) with support for `__metadata__` attribute
* `List[T]` – a generic [`typing.List[T]`](https://docs.python.org/3/library/typing.html#typing.List) type with support for `__metadata__` attribute

`List[T]` generic type can be used to create a list container which use
base types, sequence types themselves, or standard primitive types as its
elements.

## Base types

`d3m_metadata.base` module exposes specialized base types which can be used
as individual elements in a `List[T]` container. Besides these specialized
base types, and sequence types themselves, also other standard primitive
types can be used:

* `str`
* `bytes`
* `bool`
* `float`
* `int`
* `dict` (consider using [`typing.Dict`](https://docs.python.org/3/library/typing.html#typing.Dict),
  [`typing.NamedTuple`](https://docs.python.org/3/library/typing.html#typing.NamedTuple), or [`TypedDict`](https://mypy.readthedocs.io/en/stable/kinds_of_types.html#typeddict))

Specialized types available:

* `Graph` – an interface for representing graph values

## Metadata

`d3m_metadata.metadata` module provides a standard Python implementation for
metadata associated with values passed between primitives.

Metadata can be specified for a value itself (a container value) or data
contained inside the container value by specifying a `selector` which
limits given metadata just to that data. Selector is a tuple of strings,
integers, or special `ALL_CHILDREN` value, which corresponds to a series
of `[...]` Python operations on the container value.

Metadata itself is represented as a (potentially nested) dict.

### Standard metadata keys

You can use custom keys for metadata, but the following keys are standardized,
so you should use those if you are trying to represent the same metadata:
[`http://metadata.datadrivendiscovery.org/schemas/definitions.json`](http://metadata.datadrivendiscovery.org/schemas/definitions.json) ([source](./d3m_metadata/schema/metadata/definitions.json))

Keys can generally be used in different contexts:

* `primitive` – for metadata describing primitives:
  [`http://metadata.datadrivendiscovery.org/schemas/primitive.json`](http://metadata.datadrivendiscovery.org/schemas/primitive.json) ([source](./d3m_metadata/schema/metadata/primitive.json))
* `container` – for metadata describing whole container value (value passed between primitives):
  [`http://metadata.datadrivendiscovery.org/schemas/container.json`](http://metadata.datadrivendiscovery.org/schemas/container.json) ([source](./d3m_metadata/schema/metadata/container.json))
* `dimension` – for metadata describing dimension itself (e.g., rows and columns):
  [`http://metadata.datadrivendiscovery.org/schemas/dimension.json`](http://metadata.datadrivendiscovery.org/schemas/dimension.json) ([source](./d3m_metadata/schema/metadata/dimension.json))
* `datum` – for metadata describing datum itself (e.g., cells):
  [`http://metadata.datadrivendiscovery.org/schemas/datum.json`](http://metadata.datadrivendiscovery.org/schemas/datum.json) ([source](./d3m_metadata/schema/metadata/datum.json))

A more user friendly visualizaton of schemas listed above is available at
[http://metadata.datadrivendiscovery.org/](http://metadata.datadrivendiscovery.org/).

Contribute: Standardizing metadata schemas are an ongoing process. Feel free to
contribute suggestions and merge requests with improvements.
