import abc
from typing import *

from .base import *
from .transformer import TransformerPrimitiveBase

__all__ = ('PairwiseDistanceLearnerPrimitiveBase', 'PairwiseDistanceTransformerPrimitiveBase', 'InputLabels')

InputLabels = TypeVar('InputLabels', bound=Sequence)


class PairwiseDistanceLearnerPrimitiveBase(PrimitiveBase[Tuple[Inputs, Inputs], Outputs, Params], Generic[Inputs, InputLabels, Outputs, Params]):
    """
    A base class for primitives which learn distances (however defined) between two
    different sets of instances.

    Class is parametrized using four type variables, ``Inputs``, ``InputLabels``, ``Outputs``, and ``Params``.
    """

    @abc.abstractmethod
    def produce(self, *, inputs: Tuple[Inputs, Inputs], timeout: float = None, iterations: int = None) -> Outputs:
        """
        Computes distance matrix between two sets of data.

        Parameters
        ----------
        inputs : Tuple[Inputs, Inputs]
            A pair of collections of instances.
        timeout : float
            A maximum time this primitive should take to produce outputs during this method call, in seconds.
        iterations : int
            How many of internal iterations should the primitive do.

        Returns
        ---------
        Outputs
            A n by m distance matrix describing the relationship between each instance in inputs[0] and each instance
            in inputs[1] (n and m are the number of instances in inputs[0] and inputs[1], respectively).
        """

    @abc.abstractmethod
    def set_training_data(self, *, inputs: Inputs, outputs: InputLabels) -> None:
        """
        Sets training data of this primitive.

        Parameters
        ----------
        inputs : Inputs
            The inputs.
        outputs : InputLabels
            A set of class labels for the inputs.
        """


class PairwiseDistanceTransformerPrimitiveBase(TransformerPrimitiveBase[Tuple[Inputs, Inputs], Outputs]):
    """
    A base class for primitives which compute distances (however defined) between two
    different sets of instances without learning any sort of model.
    """

    @abc.abstractmethod
    def produce(self, *, inputs: Tuple[Inputs, Inputs], timeout: float = None, iterations: int = None) -> Outputs:
        """
        Computes distance matrix between two sets of data.

        Parameters
        ----------
        inputs : Tuple[Inputs, Inputs]
            A pair of collections of instances.
        timeout : float
            A maximum time this primitive should take to produce outputs during this method call, in seconds.
        iterations : int
            How many of internal iterations should the primitive do.

        Returns
        ---------
        Outputs
            A n by m distance matrix describing the relationship between each instance in inputs[0] and each instance
            in inputs[1] (n and m are the number of instances in inputs[0] and inputs[1], respectively).
        """
