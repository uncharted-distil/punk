from typing import *

from d3m_metadata.base import Graph

from .base import Outputs
from .transformer import TransformerPrimitiveBase

__all__ = ('GraphTransformerPrimitiveBase', 'Inputs')

Inputs = TypeVar('Inputs', bound=Sequence[Graph])


class GraphTransformerPrimitiveBase(TransformerPrimitiveBase[Inputs, Outputs]):
    """
    A base class for transformer primitives which take Graph objects as input.
    Graph is an interface which TA1 teams should implement for graph data.
    """
