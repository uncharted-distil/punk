# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from typing import *
from d3m_types.base import Graph
from .base import Outputs
from .transformer import TransformerPrimitiveBase
__all__ = ('GraphTransformerPrimitiveBase', 'Inputs')
Inputs = TypeVar('Inputs', bound=Sequence[Graph])


class GraphTransformerPrimitiveBase(TransformerPrimitiveBase[(Inputs, Outputs)]):
    '\n    A base class for transformer primitives which take Graph objects as input.\n    Graph is an interface which TA1 teams should implement for graph data.\n    '
