# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from .base import *
from .unsupervised_learning import UnsupervisedLearnerPrimitiveBase
__all__ = ('ClusteringPrimitiveBase',)


class ClusteringPrimitiveBase(UnsupervisedLearnerPrimitiveBase[(Inputs, Outputs, Params)]):
    '\n    A base class for primitives implementing a clustering algorithm.\n    '
