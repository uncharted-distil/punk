# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import abc
from .base import *
__all__ = ('GeneratorPrimitiveBase',)


class GeneratorPrimitiveBase(PrimitiveBase[(None, Outputs, Params)]):
    '\n    A base class for primitives which have to be fitted before they can start\n    producing (useful) outputs, but they are fitted only on output data.\n    Moreover, they do not accept any inputs to generate outputs, which is\n    represented as a list of ``None`` values to ``produce`` method to signal\n    how many outputs are requested.\n\n    A base class for primitives which are not fitted at all and can\n    simply produce (useful) outputs from inputs directly. As such they\n    also do not have any state (params).\n\n    This class is parametrized using only by two type variables, ``Outputs`` and ``Params``.\n    '

    @abc.abstractmethod
    def set_training_data(self, outputs):
        # type: (Outputs) -> None
        '\n        Sets training data of this primitive.\n\n        Parameters\n        ----------\n        outputs : Outputs\n            The outputs.\n        '
