## vNEXT

* `InspectLossMixin` renamed to `LossFunctionMixin`.
* `LossFunctionMixin`'s `get_loss_function` method now returns a value from
  problem schema `Metric` enumeration.
* `LossFunctionMixin` has now a `loss` method which allows one to ask a
  primitive to compute loss for a given set of inputs and outputs using
  internal loss function the primitive is using.

## v2017.9.27

* Initial version of the unified Python API.
